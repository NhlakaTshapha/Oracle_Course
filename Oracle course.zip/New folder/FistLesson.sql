--------------------------------------------------------------------------------Task 1
select last_name,job_id,salary as Sal
from employees;

----1.The above statement True
select * 
from job_grades;

----2. True

select employee_id,last_name
Sal * 12 Annual Salary
From employees;
--- missing comma after lastname
--- there is no column such as Sal in the employees table
--- and When reanming columne display you can not leave spaces its must be one word, unless it is in qoutation marks
---when perfoming calculations always use asteriks not x



--------------------------------------------------------------------------------Task 2
-------4.
describe Departments;
select * From departments;

-------5
---a
Describe Employees
select * from Employees;

---b
select employee_id,last_name,job_id,hire_date STARTDATE
from employees
