


-------------1
SELECT sysdate as "Date"
from dual;



-------------2 & 3
SELECT employee_id,last_name,salary,Round(salary +(salary*0.155),0) "New Salary"
FROM employees;


-------------4
SELECT employee_id,last_name,salary,Round(salary +(salary*0.155),0) "New Salary", ((salary+(salary*0.155))-salary) "Increase"
FROM employees;

-------------5
SELECT last_name,length(last_name) "Length"
FROM employees
where last_name like 'A%' or last_name like 'M%'
order by last_name;


-------------6b
SELECT INITCAP(last_name) "NAME",length(last_name) "Length"
FROM employees
where last_name like '&start_with%'
order by last_name;


-------------6c
SELECT last_name,length(last_name) "Length"
FROM employees
where last_name like Upper('&start_with%')
order by last_name;

---------------6

SELECT last_name,ROUND((MonthS_BETWEEN(SYSDATE,hire_date))) MONTH_WORDKED
FROM EMPLOYEES;


----------------7
SELECT LAST_NAME,LPAD(SALARY,15,'$') SALARY
FROM EMPLOYEES;

---------------8
SELECT LAST_NAME,
rpad(' ',(SALARY/1000)+1,'*') SALARY_IN_ASTERIK
FROM EMPLOYEES
order by salary desc;

--------------9
SELECT LAST_NAME, TRUNC((SYSDATE-HIRE_DATE)/7) AS TUNURE
FROM EMPLOYEES
WHERE department_id=90
order by TUNURE desc;































