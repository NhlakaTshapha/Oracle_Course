------------------4

Select MAX(SALARY) MAXIMUM, MIN(SALARY) MINIMUM, SUM(SALARY) SUM, ROUND(AVG(SALARY)) AVERAGE
FROM EMPLOYEES;

------------------5
Select JOB_ID, MAX(SALARY) MAXIMUM, MIN(SALARY) MINIMUM, SUM(SALARY) SUM, ROUND(AVG(SALARY)) AVERAGE
FROM EMPLOYEES
GROUP BY JOB_ID;

------------------6
SELECT JOB_ID, COUNT(*)
FROM EMPLOYEES
GROUP BY JOB_ID;


SELECT JOB_ID, COUNT(*)
FROM EMPLOYEES
WHERE JOB_ID=UPPER('&JOB_ID')
GROUP BY JOB_ID;
-------------------7
select count(manager_id) "Number of Managers"
from employees;

--------------------8
SELECT (MAX(salary)-MIN(salary)) Difference
From employees

------------------9

SELECT manager_id, Min(salary)
from employees
where manager_id is not null
group by manager_id
having min(salary) > 6000
order by Min(salary)desc;


-------------------10

SELECT count(*) Total, 
                sum(Decode(To_char(hire_date,'YYYY'),2009,1,0)) "2009",
                sum(Decode(To_char(hire_date,'YYYY'),2010,1,0)) "2010",
                sum(Decode(To_char(hire_date,'YYYY'),2011,1,0)) "2011",
                sum(Decode(To_char(hire_date,'YYYY'),2012,1,0)) "2012"
from employees;

select Count(*) Total,
                Sum(case To_char(hire_date,'YYYY') when '2009' then 1 else 0 end) "2009",
                Sum(case To_char(hire_date,'YYYY') when '2010' then 1 else 0 end) "2010",
                Sum(case To_char(hire_date,'YYYY') when '2011' then 1 else 0 end) "2011",
                Sum(case To_char(hire_date,'YYYY') when '2012' then 1 else 0 end) "2012"
From employees;
                
                
---------------------11
SELECT JOB_ID JOB, 
            SUM(DECODE(Department_id,20,salary)) "Dept 20",
            SUM(DECODE(Department_id,50,salary)) "Dept 50",
            SUM(DECODE(Department_id,80,salary)) "Dept 80",
            SUM(DECODE(Department_id,90,salary)) "Dept 90",
            Sum(salary) Total
from employees
group by job_id;
