----------------------------------1
select last_name,hire_date
from employees 
where department_id=(select department_id
                        from employees
                        where last_name='&&Name')
And last_name<>'&Name';


----------------------------------2
SELECT employee_id,last_name,salary
from employees
where salary > (select Avg(salary)
                    from employees)
order by 3;

----------------------------------3
SELECT employee_id,last_name
from employees
where department_id in (select department_id
                            from employees
                            where last_name like '%u%');

----------------------------------4
select last_name, department_id,job_id
from employees
where department_id in (select department_id
                            from departments
                            where location_id = (select location_id
                                                    from locations
                                                    where location_id=1700));
                                                    
select last_name, department_id,job_id
from employees
where department_id in (select department_id
                            from departments
                            where location_id = (select location_id
                                                    from locations
                                                    where location_id=&location_id));
----------------------------------5
SELECT  last_name, salary
from employees
where manager_id in (select employee_id
                        from employees
                        where last_name='King');
                        
----------------------------------6

select department_id,last_name,job_id
from employees
where department_id=(select department_id
                        from departments
                        where department_name='Executive');


----------------------------------7
SELECT LAST_NAME
FROM EMPLOYEES
WHERE SALARY > ANY (SELECT SALARY
                    FROM EMPLOYEES
                    WHERE DEPARTMENT_ID=60);


----------------------------------8
SELECT EMPLOYEE_ID,LAST_NAME,SALARY
FROM EMPLOYEES
WHERE  DEPARTMENT_ID IN (SELECT DEPARTMENT_ID
                        FROM EMPLOYEES
                        WHERE LAST_NAME LIKE '%u%')
AND SALARY > (SELECT AVG(SALARY)
                FROM EMPLOYEES);


select last_name,Translate(last_name,'aeiou','*#$') no_vowel
from employees
where last_name like 'S%';


-----c
select job_id,hire_date,To_char(hire_date,'fmDay,"The" ddspth," of " Month,YYYY')
from employees;


select last_name,LEAST(SALARY*1.05,SALARY*1.2) 
FROM EMPLOYEES;

select last_name,LEAST(NVL(SALARY,0)*1.05,SALARY*1.2) 
FROM EMPLOYEES;

select last_name,COALESCE(LEAST(SALARY*1.05,SALARY*1.2), SALARY*1.05) 
FROM EMPLOYEES;

SELECT COALESCE(NULL,'ORACLE','CERTIFIED')
FROM DUAL;

SELECT CURRENT_TIMESTAMP
FROM DUAL;

SELECT LOCALTIMESTAMP
FROM DUAL;

SELECT CURRENT_DATE
FROM DUAL;

select department_name,manager_id,(select last_name
                                    from employees e
                                    where e.employee_id=d.manager_id) MGR_NAME
from departments d
where ((select country_id 
            FROM Locations l
            where d.location_id=l.location_id) 
        in (select country_id FROM countries c
            where c.country_name='United States of America'
            Or c.country_name='Canada'))
        AND d.manager_id is not null;


select country_id,country_name
from countries
MINUS
select l.country_id,c.country_name
from locations l 
join countries c on (l.country_id=c.country_id)
Join departments d on (d.location_id=l.location_id);


select employee_id,job_id,department_id
from Employees
where department_id =50
Union all
select employee_id,job_id,department_id
from Employees
where department_id=80;


select last_name,salary
from employees
where salary >(select salary from employees where last_name='Abel');


select last_name, salary
from employees
where salary = any (select min(salary)
                        from employees
                        group by department_id);


------------- IN operator equivalent to = any

SELECT
    *
FROM
    employees
WHERE
    employee_id  IN (
        SELECT
            manager_id
        FROM
            employees
        WHERE manager_id is not null
    );
    
 select Concat(first_name,concat(' ',last_name)) as "Full name"
 from employees
 where manager_id=101;
    
select Concat(e.first_name,concat(' ',e.last_name)) as "Full name",e.employee_id, e.salary, e.job_id,m.manager_id,m.first_name, m.last_name
from employees e 
cross join employees m ;



-----------------------------------------------------Revision from the videos
UNDEFINE Name
select last_name ,hire_date
from employees
where department_id=(select department_id
                        from employees
                        where UPPER(last_name)=UPPER('&&Name'))
                        
AND last_name<>UPPER('&Name');


select last_name
from employees
where salary  > any (select salary 
                        from employees
                        where department_id=60);




