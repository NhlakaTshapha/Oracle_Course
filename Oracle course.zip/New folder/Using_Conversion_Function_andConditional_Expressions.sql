------------------------1
SELECT last_name||' earns '||TO_CHAR(salary,'fm$99,9999.99')||' but wants '||TO_CHAR((salary*3),'fm$99,999.99') as "Dream Salaries"
FROM Employees;

------------------------2
SELECT last_name,hire_date,
        TO_CHAR(NEXT_DAY(ADD_MONTHS(Hire_date,6),'MONDAY'),
        'fmDay, "the" Ddspth "of" Month, YYYY') REVIEW
FROM employees;
------------------------3
SELECT last_name,NVL(TO_CHAR(commission_pct),'No Commission') Comm
from Employees;

------------------------4
SELECT Job_id, Case job_id
                WHEN 'AD_PRES' THEN 'A'
                WHEN 'ST_MAN' THEN  'B'
                WHEN 'IT_PROG' THEN  'C'
                WHEN 'SA_REP' THEN  'D'
                WHEN 'ST_CLERK' THEN 'E'
                ELSE  '0' 
                END  Grade
                
FROM Employees;

------------------------5
SELECT Job_id, Case 
                WHEN job_id='AD_PRES' THEN 'A'
                WHEN job_id='ST_MAN' THEN  'B'
                WHEN job_id='IT_PROG' THEN  'C'
                WHEN job_id='SA_REP' THEN  'D'
                WHEN job_id='ST_CLERK' THEN 'E'
                ELSE  '0' 
                END  Grade
                
FROM Employees;
                
------------------------6              
SELECT Job_id,  Decode(job_id,
                            'ST_CLERK', 'E',
                            'SA_REP',   'D',
                            'IT_PROG',  'C',
                            'ST_MAN',   'B',
                            'AD_PRES',  'A',
                            '0') GRADE
FROM Employees;

------------------------7
