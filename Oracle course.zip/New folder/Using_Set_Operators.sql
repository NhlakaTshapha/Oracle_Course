
select department_id
from employees
minus
select department_id
from employees
where job_id = 'ST_CLERK';



select country_id,country_name
from countries
minus
select l.country_id,c.country_name
from locations l  join countries c
on (c.country_id=l.country_id)
Join departments d
on(l.location_id=d.location_id);


select employee_id,job_id,department_id
from employees
where department_id=50
Union all
select employee_id,job_id,department_id
from employees
where department_id=80;



select employee_id
from employees
where job_id='SA_REP'
intersect
select employee_id
from employees
where department_id=80;


select last_name, department_id, null departName
from employees 
union
select null, department_id, department_name
from departments; 


---------------------------------------------------------------------Revision from the book

Select department_id 
from DEPARTMENTS
minus
Select department_id 
from employees
where job_id='ST_CLERK';


SELECT COUNTRY_ID,COUNTRY_NAME
FROM COUNTRIES

MINUS

SELECT L.COUNTRY_ID,C.COUNTRY_NAME
FROM COUNTRIES C
JOIN LOCATIONS L
ON L.COUNTRY_ID =C.COUNTRY_ID
JOIN DEPARTMENTS D
ON D.LOCATION_ID=L.LOCATION_ID;



SELECT EMPLOYEE_ID 
FROM EMPLOYEES
WHERE JOB_ID='SA_REP'
INTERSECT
SELECT EMPLOYEE_ID 
FROM EMPLOYEES
WHERE DEPARTMENT_ID=(SELECT DEPARTMENT_ID FROM DEPARTMENTS WHERE DEPARTMENT_NAME='Sales');




